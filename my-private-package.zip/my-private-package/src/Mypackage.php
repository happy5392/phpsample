<?php
namespace Kamakshyaprasadkar\MyPrivatePackage;

class MyPackage
{
    public function sayHello()
    {
        return "Hello from MyPackage!";
    }
}
